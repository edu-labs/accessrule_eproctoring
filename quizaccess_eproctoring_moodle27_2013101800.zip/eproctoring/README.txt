eProctoring quiz access rule (identity validation)

This quiz access rule was created by Edu Labs and eProctoring.com. 

Once installed on /mod/quiz/accessrule go to the Site administration -> Notifications section and the plugin will install

https://eProctoring.com